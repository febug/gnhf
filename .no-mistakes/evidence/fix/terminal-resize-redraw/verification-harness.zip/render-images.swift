import AppKit
import CoreText
import Foundation

// Rasterize the real xterm/headless cell buffer, not a replacement product UI.
let evidence = "/private/tmp/find-pr-gnhf-no-mistakes/state/evidence/01M78RVVS6Y6C8BAX8NHGPCJ5Z"
let choices = [
  ("demo-candidate", "initial-readable", "Initial 120 x 40 viewport"),
  ("git-candidate", "rapid-before-repaint", "Rapid resize: clipped buffer before repaint"),
  ("git-candidate", "rapid-recovered", "Rapid resize: complete title and prompt restored"),
  ("git-candidate", "delayed-recovered", "Real CLI Git hook: complete title and prompt restored"),
  ("git-baseline", "delayed-recovered", "Base commit: title and prompt remain missing"),
  ("git-candidate", "slow-80x24", "Sustained 80 x 24 resize"),
  ("git-candidate", "graceful-wait", "Single Ctrl+C: finishes the active iteration"),
  ("git-candidate", "stopped", "Graceful exit: terminal restored; two real commits")
]
func color(_ mode: Int, _ value: Int, _ fallback: NSColor) -> NSColor {
  if mode == 0x3000000 {
    return NSColor(srgbRed: CGFloat((value >> 16) & 255)/255, green: CGFloat((value >> 8)&255)/255, blue: CGFloat(value&255)/255, alpha: 1)
  }
  if mode == 0x1000000 || mode == 0x2000000 {
    let palette: [Int] = [0x000000,0xcd0000,0x00cd00,0xcdcd00,0x0000ee,0xcd00cd,0x00cdcd,0xe5e5e5,0x7f7f7f,0xff0000,0x00ff00,0xffff00,0x5c5cff,0xff00ff,0x00ffff,0xffffff]
    if value < 16 { return color(0x3000000,palette[max(0,value)],fallback) }
    if value >= 232 { return NSColor(white: CGFloat(8+10*(value-232))/255, alpha:1) }
    let v=value-16
    let parts=[v/36,(v/6)%6,v%6].map { $0 == 0 ? 0 : 55+40*$0 }
    return NSColor(srgbRed:CGFloat(parts[0])/255,green:CGFloat(parts[1])/255,blue:CGFloat(parts[2])/255,alpha:1)
  }
  return fallback
}
guard let regular=NSFont(name:"Menlo-Regular",size:16), let bold=NSFont(name:"Menlo-Bold",size:16) else {
  fatalError("Menlo unavailable; cannot claim faithful monospace rendering")
}
print("Fonts: \(regular.fontName), \(bold.fontName); native AppKit Unicode fallback")
for (label,key,caption) in choices {
  let data=try Data(contentsOf:URL(fileURLWithPath:evidence+"/"+label+"-screens.json"))
  let screens=try JSONSerialization.jsonObject(with:data) as! [String:Any]
  let screen=screens[key] as! [String:Any]
  let columns=screen["cols"] as! Int, rows=screen["rows"] as! Int
  let cells=screen["cells"] as! [[[String:Any]]]
  let width=columns*10+48, height=rows*22+102
  let cg=CGContext(data:nil,width:width*2,height:height*2,bitsPerComponent:8,bytesPerRow:0,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
  cg.scaleBy(x:2,y:2)
  NSGraphicsContext.saveGraphicsState()
  NSGraphicsContext.current=NSGraphicsContext(cgContext:cg,flipped:false)
  NSColor(calibratedWhite:0.07,alpha:1).setFill()
  NSRect(x:0,y:0,width:width,height:height).fill()
  let header:[NSAttributedString.Key:Any]=[.font:NSFont.systemFont(ofSize:17,weight:.semibold),.foregroundColor:NSColor.white]
  (caption as NSString).draw(at:NSPoint(x:24,y:height-32),withAttributes:header)
  let sub:[NSAttributedString.Key:Any]=[.font:NSFont.systemFont(ofSize:11),.foregroundColor:NSColor.gray]
  ("PTY + xterm Unicode 11 terminal replay | Node 24.13.0 | macOS | not a desktop screenshot" as NSString).draw(at:NSPoint(x:24,y:height-52),withAttributes:sub)
  NSColor.black.setFill()
  NSRect(x:16,y:20,width:columns*10+16,height:rows*22+16).fill()
  for (y,row) in cells.enumerated() {
    for (x,c) in row.enumerated() {
      let cellWidth=c["width"] as! Int
      if cellWidth == 0 { continue }
      let text=c["text"] as! String
      let rect=NSRect(x:24+x*10,y:28+(rows-y-1)*22,width:cellWidth*10,height:22)
      let bg=color(c["bgMode"] as? Int ?? 0,c["bg"] as? Int ?? 0,NSColor.black)
      bg.setFill();rect.fill()
      var fg=color(c["fgMode"] as? Int ?? 0,c["fg"] as? Int ?? 0,NSColor(calibratedWhite:0.85,alpha:1))
      if c["dim"] as? Bool == true { fg=fg.withAlphaComponent(0.5) }
      let attrs:[NSAttributedString.Key:Any]=[.font:c["bold"] as? Bool == true ? bold : regular,.foregroundColor:fg]
      let line=CTLineCreateWithAttributedString(NSAttributedString(string:text,attributes:attrs))
      cg.saveGState()
      cg.clip(to:rect)
      cg.textMatrix = .identity
      cg.textPosition=CGPoint(x:rect.minX,y:rect.minY+4)
      CTLineDraw(line,cg)
      cg.restoreGState()
    }
  }
  NSGraphicsContext.restoreGraphicsState()
  let image=cg.makeImage()!
  let png=NSBitmapImageRep(cgImage:image).representation(using:.png,properties:[:])!
  let url=URL(fileURLWithPath:evidence+"/"+label+"-"+key+".png")
  try png.write(to:url)
  print(url.lastPathComponent)
}
