#!/usr/bin/env node
// External provider protocol fixture. The CLI, renderer, orchestrator, Git,
// pre-commit hook and terminal remain real. No provider account is consulted.
import fs from 'node:fs';
import path from 'node:path';
import { setTimeout } from 'node:timers/promises';
const root = process.env.RESIZE_FIXTURE;
const counter = path.join(root, 'provider-count');
const n = fs.existsSync(counter) ? Number(fs.readFileSync(counter, 'utf8')) + 1 : 1;
fs.writeFileSync(counter, String(n));
fs.writeFileSync(path.join(root, `provider-${n}-started`), String(process.pid));
const deadline = Date.now() + 15000;
while (!fs.existsSync(path.join(root, `provider-${n}-release`))) {
  if (Date.now() > deadline) process.exit(4);
  await setTimeout(5);
}
fs.writeFileSync(`change-${n}.txt`, `Synthetic iteration ${n}\n`);
console.log(JSON.stringify({type:'result', subtype:'success', is_error:false,
  total_cost_usd:0, usage:{input_tokens:12,output_tokens:7,cache_read_input_tokens:0,cache_creation_input_tokens:0},
  structured_output:{success:true,summary:`Synthetic iteration ${n} complete`,key_changes_made:[`change-${n}.txt`],key_learnings:[]}}));
