const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {Terminal} = require('/private/tmp/find-pr-gnhf-terminal/node_modules/@xterm/headless');
const {Unicode11Addon} = require('/private/tmp/find-pr-gnhf-terminal/node_modules/@xterm/addon-unicode11');
const E = '/private/tmp/find-pr-gnhf-no-mistakes/state/evidence/01M78RVVS6Y6C8BAX8NHGPCJ5Z';
const title = 'g n h f';
const demoPrompt = "let's minimize app startup latency without sacrificing any functionality";
const gitPrompt = 'ship a readable terminal after resize';
const stripOsc = text => text.replace(/\x1b\][^\x07]*\x07/g, '');
function marker(events, name) {
  const index = events.findIndex(e => e.kind === 'checkpoint' && e.name === name || e.kind === name);
  assert(index >= 0, `missing ${name}`);
  return index;
}
function between(events, first, last) {
  const begin = marker(events, first), end = marker(events, last);
  assert(end > begin);
  return events.slice(begin+1,end).filter(e=>e.kind==='output').map(e=>e.data).join('');
}
function readable(screen, prompt) {
  const pattern = new RegExp(prompt.split(' ').join('[^\\p{L}\\p{N}]+'), 'u');
  const text = screen.lines.join('\n');
  return text.includes(title) && pattern.test(text);
}
async function replay(label) {
  const events = fs.readFileSync(path.join(E,label+'-pty.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
  const observations = fs.readFileSync(path.join(E,label+'-observations.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
  const result = JSON.parse(fs.readFileSync(path.join(E,label+'-process.json')));
  const prompt = result.demo ? demoPrompt : gitPrompt;
  const term = new Terminal({cols:120,rows:40,allowProposedApi:true,scrollback:0});
  term.loadAddon(new Unicode11Addon());
  term.unicode.activeVersion = '11';
  const screens = {};
  for (const e of events) {
    if (e.kind==='output') await new Promise(resolve=>term.write(e.data,resolve));
    if (e.kind==='resize') term.resize(e.columns,e.rows);
    if (e.kind==='checkpoint') {
      const buffer=term.buffer.active, lines=[],cells=[];
      for(let y=0;y<term.rows;y++) {
        const line=buffer.getLine(buffer.viewportY+y);
        lines.push(line?.translateToString(true,0,term.cols)||'');
        const row=[];
        for(let x=0;x<term.cols;x++) {
          const c=line?.getCell(x);
          row.push({text:c?.getChars()||'',width:c?.getWidth()||0,bold:!!c?.isBold(),dim:!!c?.isDim(),
            fg:c?.getFgColor(),fgMode:c?.getFgColorMode(),bg:c?.getBgColor(),bgMode:c?.getBgColorMode()});
        }
        cells.push(row);
      }
      screens[e.name]={label,checkpoint:e.name,time:e.t,cols:term.cols,rows:term.rows,buffer:buffer.type,lines,cells};
      fs.writeFileSync(path.join(E,`${label}-${e.name}.txt`),lines.join('\n')+'\n');
    }
  }
  term.dispose();
  fs.writeFileSync(path.join(E,label+'-screens.json'),JSON.stringify(screens));
  const ordinary=between(events,'ordinary-start','ordinary-end');
  result.ordinary={readable:readable(screens['initial-readable'],prompt),outputBytes:Buffer.byteLength(ordinary),fullRepaints:ordinary.split('\x1b[H').length-1,reprintedPrompt:ordinary.includes(prompt.slice(0,20))};
  const stopping=between(events,'before-ctrl-c','stopped');
  const stop=observations.find(e=>e.event==='renderer-stopped')||observations.find(e=>e.event==='exit');
  result.shutdown={listenersRestored:stop?.listenersRestored,stdinRaw:stop?.stdinRaw,
    normalBuffer:screens.stopped.buffer==='normal',cursorRestored:stopping.includes('\x1b[?25h'),
    titleCleared:stopping.includes('\x1b]2;\x07'),ctrlCInputs:events.filter(e=>e.kind==='input'&&e.data==='\u0003').length};
  {
    const repaint=stripOsc(between(events,'rapid-before-repaint','rapid-recovered'));
    const csi=repaint.match(/\x1b\[[0-9;]*[Hf]/);
    result.rapid={damagedBeforeRepaint:!readable(screens['rapid-before-repaint'],prompt),
      readableAfter:readable(screens['rapid-recovered'],prompt),
      firstPaintIsFullFrame:csi?.[0]==='\x1b[H',reprintedTitle:repaint.includes(title),reprintedPrompt:repaint.includes(prompt.slice(0,20)),
      outputWhileSmall:between(events,'rapid-before','rapid-before-repaint'),
      resumedDifferential:!between(events,'rapid-recovered','rapid-differential').includes('\x1b[H')};
    result.slow=['slow-80x24','slow-100x30','slow-120x40'].map(name=>({name,readable:readable(screens[name],prompt)}));
  }
  if (result.demo) {
    result.shutdown.postStopOutput=between(events,'stopped','post-stop-resize');
  } else {
    const start=events[marker(events,'hook-blocked')].wallMs;
    const released=events[marker(events,'release-hook')].wallMs;
    const end=events[marker(events,'delayed-recovered')].wallMs;
    const obs=observations.filter(e=>e.time>=start&&e.time<=end);
    const signalIndex = obs.findIndex(e=>e.event==='kernel-sigwinch'&&e.time>=released);
    const firstPaint = obs.slice(signalIndex+1).find(e=>e.event==='terminal-write');
    const repaint=stripOsc(between(events,'release-hook','delayed-recovered'));
    const csi=repaint.match(/\x1b\[[0-9;]*[Hf]/);
    result.delayed={readableBefore:readable(screens['delayed-before'],prompt),
      damagedBeforeRepaint:!readable(screens['delayed-before-repaint'],prompt),readableAfter:readable(screens['delayed-recovered'],prompt),
      outputWhileHookBlocked:between(events,'hook-blocked','release-hook'),
      deliveredSignalAtOriginalSize:obs.some(e=>e.event==='kernel-sigwinch'&&e.time>=released&&e.columns===120&&e.rows===40),
      stdoutResizeEvents:obs.filter(e=>e.event==='stdout-resize').length,
      firstPaintAfterSignalIsFullFrame:firstPaint?.fullFrame,
      firstPaintAfterSignalRestoresContent:!!(firstPaint?.title && firstPaint?.gitPrompt),
      firstPaintAfterSignalMs:firstPaint?.time-obs[signalIndex]?.time,
      frameBeforeSignalWasDifferential:csi?.[0]!=='\x1b[H',
      reprintedTitle:repaint.includes(title),reprintedPrompt:repaint.includes(prompt),
      resumedDifferential:!between(events,'delayed-recovered','delayed-differential').includes('\x1b[H')};
  }
  fs.writeFileSync(path.join(E,label+'-results.json'),JSON.stringify(result,null,2)+'\n');
  return {result,screens};
}
const escape = s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
function color(mode, value, fallback) {
  if(mode===0x3000000) return '#'+value.toString(16).padStart(6,'0');
  if(mode===0x1000000 || mode===0x2000000) {
    const palette=['#000000','#cd0000','#00cd00','#cdcd00','#0000ee','#cd00cd','#00cdcd','#e5e5e5','#7f7f7f','#ff0000','#00ff00','#ffff00','#5c5cff','#ff00ff','#00ffff','#ffffff'];
    if(value<16)return palette[value];
    if(value>=232){const n=(8+10*(value-232)).toString(16).padStart(2,'0');return '#'+n+n+n;}
    const v=value-16, rgb=[Math.floor(v/36),Math.floor(v/6)%6,v%6].map(n=>n===0?0:55+40*n);
    return '#'+rgb.map(n=>n.toString(16).padStart(2,'0')).join('');
  }
  return fallback;
}
function screenHtml(screen) {
  const rows=screen.cells.map(row=>'<div class="row">'+row.map((c,x)=>c.width?`<span style="left:${x*9}px;width:${c.width*9}px;color:${color(c.fgMode,c.fg,'#ddd')};background:${color(c.bgMode,c.bg,'transparent')};font-weight:${c.bold?'bold':'normal'};opacity:${c.dim?0.5:1}">${escape(c.text||' ')}</span>`:'').join('')+'</div>').join('');
  return `<div class="terminal" style="width:${screen.cols*9}px">${rows}</div>`;
}
(async()=>{
  const demo=await replay('demo-candidate'), candidate=await replay('git-candidate'), baseline=await replay('git-baseline');
  const chosen=[
    [demo,'initial-readable','Demo: initial 120 × 40'],
    [candidate,'rapid-before-repaint','Rapid round trip: damaged alternate buffer before next frame'],
    [candidate,'rapid-recovered','Rapid round trip: title and complete prompt restored'],
    [candidate,'delayed-recovered','Real CLI Git hook: title and prompt restored on next frame'],
    [baseline,'delayed-recovered','Base commit: title and prompt remain missing after Git hook'],
    [candidate,'slow-80x24','Slow resize: readable 80 × 24 viewport'],
    [candidate,'graceful-wait','Single Ctrl+C: waiting for the active synthetic iteration'],
    [candidate,'stopped','Graceful exit: committed work and terminal restored'],
  ];
  let html='<!doctype html><html lang="en"><meta charset="utf-8"><title>gnhf resize: fresh terminal replay</title><style>body{background:#161616;color:#ddd;font:14px/1.5 system-ui;margin:24px}h1{font-size:24px}h2{font-size:17px;margin-top:32px}.terminal{background:#000;padding:12px;overflow:hidden}.row{height:19px;position:relative;white-space:pre;font:14px/19px Menlo,"Apple Color Emoji",monospace}.row span{position:absolute;top:0;overflow:hidden}p{max-width:1000px}a{color:#ddd}section{width:max-content}</style><h1>gnhf terminal resize evidence</h1><p>Fresh macOS execution using Node 24.13.0. These are captured PTY bytes interpreted by xterm/headless 6.0.0 with Unicode 11, rendered cell for cell. They are terminal replays, not desktop recordings. The demo uses the built-in offline mode. The Git run uses the real CLI, renderer, orchestrator and Git, with an isolated synthetic provider protocol fixture.</p><p>Scope: delivered macOS resize notifications, including dispatch delayed by a synchronous Git hook. Windows was not run. A Windows shrink-and-return entirely missed by libuv remains outside this fix. No periodic repainting was added. Refs #166.</p>';
  for(const [run,key,caption] of chosen) html+=`<section id="${run.result.label}-${key}"><h2>${escape(caption)}</h2>${screenHtml(run.screens[key])}</section>`;
  fs.writeFileSync(path.join(E,'terminal-replay.html'),html+'</html>');
  for(const r of [demo.result,candidate.result]) {
    assert.equal(r.ordinary.readable,true);
    assert(r.ordinary.outputBytes>0);
    assert.equal(r.ordinary.fullRepaints,0);
    assert.equal(r.ordinary.reprintedPrompt,false);
    assert.equal(r.providerSurvivors.length,0);
    for(const key of ['listenersRestored','normalBuffer','cursorRestored','titleCleared']) assert.equal(r.shutdown[key],true,key);
    assert.equal(r.shutdown.stdinRaw,false);
    assert.equal(r.shutdown.ctrlCInputs,1);
  }
  assert.equal(demo.result.exitCode,0);
  assert.equal(demo.result.termiosRestored,true);
  assert.equal(demo.result.shutdown.postStopOutput,'');
  for(const key of ['damagedBeforeRepaint','readableAfter','firstPaintIsFullFrame','reprintedTitle','reprintedPrompt','resumedDifferential']) assert.equal(demo.result.rapid[key],true,key);
  assert.equal(demo.result.rapid.outputWhileSmall,'');
  for(const row of demo.result.slow) assert.equal(row.readable,true,row.name);
  for(const key of ['damagedBeforeRepaint','readableAfter','firstPaintIsFullFrame','reprintedTitle','reprintedPrompt','resumedDifferential']) assert.equal(candidate.result.rapid[key],true,'real CLI rapid '+key);
  assert.equal(candidate.result.rapid.outputWhileSmall,'');
  for(const row of candidate.result.slow) assert.equal(row.readable,true,'real CLI '+row.name);
  assert.equal(candidate.result.exitCode,130);
  assert.equal(candidate.result.fixtureCommitCount,3);
  for(const key of ['readableBefore','damagedBeforeRepaint','readableAfter','deliveredSignalAtOriginalSize','firstPaintAfterSignalIsFullFrame','firstPaintAfterSignalRestoresContent','reprintedTitle','reprintedPrompt','resumedDifferential']) assert.equal(candidate.result.delayed[key],true,key);
  assert.equal(candidate.result.delayed.stdoutResizeEvents,0);
  assert.equal(candidate.result.delayed.outputWhileHookBlocked,'');
  assert.equal(baseline.result.exitCode,130);
  assert.equal(baseline.result.fixtureCommitCount,3);
  assert.equal(baseline.result.delayed.readableBefore,true);
  assert.equal(baseline.result.delayed.damagedBeforeRepaint,true);
  assert.equal(baseline.result.delayed.readableAfter,false);
  assert.equal(baseline.result.delayed.deliveredSignalAtOriginalSize,true);
  assert.equal(baseline.result.delayed.stdoutResizeEvents,0);
  fs.writeFileSync(path.join(E,'results.json'),JSON.stringify({demo:demo.result,candidate:candidate.result,baseline:baseline.result},null,2)+'\n');
  console.log(JSON.stringify({demo:demo.result,candidate:candidate.result,baseline:baseline.result},null,2));
  console.log('All scoped live contracts passed; the base reproduces the missing title and prompt.');
})().catch(error=>{console.error(error);process.exitCode=1});
