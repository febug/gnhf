import codecs, fcntl, hashlib, json, os, pathlib, platform, pty, select, signal, struct, subprocess, termios, time

ROOT = pathlib.Path.cwd()
WORK = ROOT / '.resize-verification'
EVIDENCE = pathlib.Path('/private/tmp/find-pr-gnhf-no-mistakes/state/evidence/01M78RVVS6Y6C8BAX8NHGPCJ5Z')
NODE = '/Users/gavin/.local/state/fnm_multishells/9438_1794407249291/bin/node'
PROMPT = 'ship a readable terminal after resize'
(WORK / 'provider.mjs').chmod(0o755)

def run(label, executable, idle=False):
    fixture = WORK / (label + '-fixture')
    fixture.mkdir()
    for name in ('home', 'config', 'cache', 'tmp', 'repo'):
        (fixture / name).mkdir()
    env = {
        'PATH': str(pathlib.Path(NODE).parent) + ':/usr/bin:/bin:/usr/sbin:/sbin',
        'HOME': str(fixture / 'home'), 'USERPROFILE': str(fixture / 'home'),
        'XDG_CONFIG_HOME': str(fixture / 'config'), 'XDG_CACHE_HOME': str(fixture / 'cache'),
        'TMPDIR': str(fixture / 'tmp'), 'TERM': 'xterm-256color', 'LANG': 'en_US.UTF-8',
        'GNHF_TELEMETRY': '0', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
        'GIT_TERMINAL_PROMPT':'0',
        'RESIZE_FIXTURE': str(fixture), 'RESIZE_OBSERVATIONS': str(EVIDENCE / (label + '-observations.jsonl')),
    }
    def git(*args):
        return subprocess.run(['git', '-C', str(fixture / 'repo'), *args], env=env, capture_output=True, check=True)
    git('init', '-b', 'main', '-q')
    git('config', 'user.name', 'Resize Verification')
    git('config', 'user.email', 'resize@example.invalid')
    (fixture / 'repo/README.md').write_text('# Disposable resize fixture\n')
    git('add', 'README.md')
    git('commit', '-qm', 'fixture')
    hook = fixture / 'repo/.git/hooks/pre-commit'
    hook.write_text('''#!/usr/bin/python3
import os, pathlib, time
root = pathlib.Path(os.environ['RESIZE_FIXTURE'])
(root / 'hook-started').write_text(str(os.getpid()))
deadline = time.monotonic() + 8
while not (root / 'hook-release').exists():
    if time.monotonic() > deadline:
        raise SystemExit(3)
    time.sleep(0.005)
''')
    hook.chmod(0o755)
    (fixture / 'home/.gnhf').mkdir()
    (fixture / 'home/.gnhf/config.yml').write_text(
        'agent: claude\npreventSleep: false\nagentPathOverride:\n  claude: ' + str(WORK / 'provider.mjs') + '\n')
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', 40, 120, 0, 0))
    initial_termios = termios.tcgetattr(slave)
    initial_stty = subprocess.check_output(['stty', '-g'], stdin=slave, env=env, text=True).strip()
    def setup():
        os.setsid()
        fcntl.ioctl(slave, termios.TIOCSCTTY, 0)
        os.tcsetpgrp(slave, os.getpid())
    args = [PROMPT, '--agent', 'claude', '--current-branch', '--prevent-sleep', 'off', '--meteor-frequency', '0', '--max-iterations', '2']
    command = [NODE, '--require', str(WORK / 'observe.cjs'), str(executable), *args]
    child = subprocess.Popen(command, stdin=slave, stdout=slave, stderr=slave, cwd=fixture / 'repo', env=env, preexec_fn=setup)
    fcntl.fcntl(master, fcntl.F_SETFL, os.O_NONBLOCK)
    decoder = codecs.getincrementaldecoder('utf8')('replace')
    start = time.monotonic()
    events, raw = [], bytearray()
    def event(kind, **data):
        events.append(dict(t=round(time.monotonic() - start, 6), wallMs=round(time.time()*1000), kind=kind, **data))
    event('launch', command=command, columns=120, rows=40, node=subprocess.check_output([NODE, '--version'], text=True).strip(), platform=platform.system(), sha256=hashlib.sha256(executable.read_bytes()).hexdigest())
    def drain(seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            ready, _, _ = select.select([master], [], [], max(0, min(.015, end-time.monotonic())))
            if ready:
                try:
                    data = os.read(master, 65536)
                except BlockingIOError:
                    continue
                except OSError:
                    return
                if not data: return
                raw.extend(data)
                decoded = decoder.decode(data)
                if decoded: event('output', data=decoded)
    def until(predicate, timeout=4):
        end = time.monotonic() + timeout
        while time.monotonic() < end and not predicate():
            if child.poll() is not None:
                drain(.03)
                raise RuntimeError('CLI exited early: ' + repr(raw[-1200:]))
            drain(.01)
        if not predicate(): raise RuntimeError('Timed out waiting for live CLI boundary')
    def checkpoint(name): event('checkpoint', name=name)
    def resize(columns, rows):
        event('resize', columns=columns, rows=rows)
        fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack('HHHH', rows, columns, 0, 0))
    result = {'label': label, 'idle': idle}
    restored_termios = None
    try:
        expected = PROMPT.encode()
        until(lambda: b'g n h f' in raw and expected in raw)
        drain(.65)
        checkpoint('initial-readable')
        checkpoint('ordinary-start')
        drain(.85)
        checkpoint('ordinary-end')
        if idle:
            count = len(events)
            until(lambda: any(e['kind'] == 'output' for e in events[count:]))
            drain(.01)
            checkpoint('rapid-before')
            resize(40, 8)
            drain(.05)
            resize(120, 40)
            checkpoint('rapid-before-repaint')
            drain(.45)
            checkpoint('rapid-recovered')
            drain(.85)
            checkpoint('rapid-differential')
            for cols, rows in [(80,24),(100,30),(120,40)]:
                resize(cols,rows)
                drain(.65)
                checkpoint(f'slow-{cols}x{rows}')
        else:
            until(lambda: (fixture / 'provider-1-started').exists())
            checkpoint('delayed-before')
            (fixture / 'provider-1-release').write_text('go')
            until(lambda: (fixture / 'hook-started').exists())
            event('hook-blocked')
            resize(40, 8)
            drain(.05)
            resize(120, 40)
            checkpoint('delayed-before-repaint')
            drain(.08)
            event('release-hook')
            (fixture / 'hook-release').write_text('go')
            until(lambda: (fixture / 'provider-2-started').exists())
            drain(.6)
            checkpoint('delayed-recovered')
            drain(.85)
            checkpoint('delayed-differential')
        checkpoint('before-ctrl-c')
        event('input', data='\u0003')
        os.write(master, b'\x03')
        drain(.25)
        checkpoint('graceful-wait')
        result['aliveDuringGracefulWait'] = child.poll() is None
        if idle:
            # Finish the active real iteration after its one graceful interrupt.
            (fixture / 'hook-release').write_text('go')
            (fixture / 'provider-1-release').write_text('go')
        else:
            (fixture / 'provider-2-release').write_text('go')
        until(lambda: child.poll() is not None, timeout=9)
        drain(.05)
        checkpoint('stopped')
        # macOS revokes the slave after its session leader exits. Inspect the
        # final attributes from inside the still-live CLI's exit observer.
        observations = [json.loads(line) for line in (EVIDENCE / (label + '-observations.jsonl')).read_text().splitlines()]
        final_stty = next(e['stty'] for e in reversed(observations) if e['event'] == 'exit')
        restored_termios = initial_stty == final_stty
        child.wait(timeout=3)
        drain(.03)
        result.update(exitCode=child.returncode, termiosRestored=restored_termios, initialStty=initial_stty, finalStty=final_stty,
                      fixtureCommitCount=int(git('rev-list', '--count', 'HEAD').stdout))
        (EVIDENCE / (label + '-git-log.txt')).write_bytes(git('log','--oneline').stdout)
        (EVIDENCE / (label + '-git-status.txt')).write_bytes(git('status','--porcelain').stdout)
        run_dirs = list((fixture / 'repo/.gnhf/runs').iterdir())
        assert len(run_dirs) == 1
        for name in ('gnhf.log','iterations.jsonl'):
            source = run_dirs[0] / name
            if source.exists(): (EVIDENCE / (label + '-' + name)).write_bytes(source.read_bytes())
    except Exception as ex:
        result['error'] = str(ex)
        raise
    finally:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=3)
        event('exit', code=child.returncode)
        # Providers are spawned in separate process groups by the real CLI.
        survivors=[]
        for file in fixture.glob('provider-*-started'):
            pid=int(file.read_text())
            try:
                os.kill(pid,0)
                survivors.append(pid)
                os.killpg(pid,signal.SIGKILL)
            except ProcessLookupError: pass
        result['providerSurvivors'] = survivors
        os.close(master)
        os.close(slave)
        (EVIDENCE / (label + '-pty.jsonl')).write_text(''.join(json.dumps(e) + '\n' for e in events))
        (EVIDENCE / (label + '-terminal.ansi')).write_bytes(raw)
        (EVIDENCE / (label + '-process.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)

run('idle-candidate', ROOT / 'dist/cli.mjs', idle=True)
run('git-candidate', ROOT / 'dist/cli.mjs')
run('git-baseline', WORK / 'cli.mjs')
