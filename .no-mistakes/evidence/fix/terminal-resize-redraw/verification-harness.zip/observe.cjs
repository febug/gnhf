// Observe real process events only. Do not inject signals or replace product IO.
const fs = require('node:fs');
const path = require('node:path');
const root = process.env.RESIZE_FIXTURE;
const logFile = process.env.RESIZE_OBSERVATIONS;
void process.stdout;
void process.stderr;
const log = (event, extra = {}) => fs.appendFileSync(logFile, JSON.stringify({
  time: Date.now(), event, columns: process.stdout.columns, rows: process.stdout.rows,
  sigwinchListeners: process.listenerCount('SIGWINCH'), ...extra,
}) + '\n');
process.on('SIGWINCH', () => log('kernel-sigwinch'));
process.stdout.on('resize', () => log('stdout-resize'));
const expected = process.listeners('SIGWINCH');
log('preload');
const originalWrite = process.stdout.write;
process.stdout.write = function (...args) {
  const chunk = args[0];
  if (typeof chunk === 'string' && /\x1b\[[0-9;]*H/.test(chunk)) {
    log('terminal-write', {fullFrame:chunk.startsWith('\x1b[H'),
      title:chunk.includes('g n h f'),
      demoPrompt:chunk.includes("let's minimize app startup"),
      gitPrompt:chunk.includes('ship a readable terminal after resize')});
  }
  return originalWrite.apply(this, args);
};
const stopped = () => ({
  listenersRestored: expected.length === process.listeners('SIGWINCH').length && expected.every((fn, i) => process.listeners('SIGWINCH')[i] === fn),
  stdinRaw: process.stdin.isRaw, listeners: process.listeners('SIGWINCH').map(fn => fn.name),
});
let exiting = false;
process.on('beforeExit', () => {
  if (exiting) return;
  exiting = true;
  log('renderer-stopped', stopped());
  fs.writeFileSync(path.join(root, 'renderer-stopped'), 'ready');
  // Observe a resize after the real renderer stops, without restarting it.
  setTimeout(() => log('post-stop-resize-complete'), 650);
});
process.on('exit', (code) => log('exit', { code, ...stopped() }));
