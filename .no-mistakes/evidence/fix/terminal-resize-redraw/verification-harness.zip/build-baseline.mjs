import { build } from 'tsdown';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';
const renderer = resolve('src/renderer.ts');
const original = execFileSync('git', ['show', '3e1179f8460ac53779063d1ca9dfa2c02ec02e38:src/renderer.ts'], { encoding: 'utf8' });
await build({
  config: false, entry: ['src/cli.ts'], format: 'esm', platform: 'node', target: 'node20',
  clean: false, outDir: '.resize-validation', dts: false,
  define: { __GNHF_UMAMI_HOST__: '""', __GNHF_UMAMI_WEBSITE_ID__: '""' },
  plugins: [{ name: 'load-original-renderer', load(id) { if (id === renderer) return original; } }],
});
